#Libraries needed
library(ggplot2)

#Data sets imported
lm <-fread('./project/volume/data/processed/submit_lm.csv')
glm <-fread('./project/volume/data/processed/submit_glm.csv')
plm <-fread('./project/volume/data/processed/submit_plm.csv')
sl <-fread('./project/volume/data/processed/submit_SL.csv')

#Assigning each data set a label regarding which model they are
lm$Model <- "lm"
glm$Model <- "glm"
plm$Model <- "plm"
sl$Model <- "sl"

#Removing var Id
lm <- subset(lm, select = c(SalePrice, Model))
glm <- subset(glm, select = c(SalePrice, Model))
plm <- subset(plm, select = c(SalePrice, Model))
sl <- subset(sl, select = c(SalePrice, Model))

#Creating a master data set with each sale price and its respective model used
master <- NULL
master <- rbind(master, lm)
master <- rbind(master, glm)
master <- rbind(master, plm)
master <- rbind(master, sl)
master

#Data Visualizations

#Histogram comparing the Predicted Sale Price vs Total Count
ggplot(master) +
  aes(x = SalePrice/10000) +
  geom_histogram() +
  scale_color_hue(direction = 1) +
  theme_minimal() +
  facet_wrap(vars(Model)) +
  theme(plot.title = element_text(size = 12, vjust = 3.2, hjust = 0.5)) +
  labs(title = "Predicted Sale Price vs Count by Machine Learning Models") +
  xlab("\nPredicted Sale Price (Ten Thousands of USD)")

#Boxplot comparing the Models used to predict the Sale Price
ggplot(master) +
  aes(x = SalePrice/10000, y= Model) +
  geom_boxplot(shape="circle") +
  scale_color_hue(direction = 1) +
  theme_minimal() +
  theme(plot.title = element_text(size = 12, vjust = 3.2, hjust = 0.5)) +
  labs(title = "Predicted Sale Price vs Machine Learning Models") +
  xlab("\nPredicted Sale Price (Ten Thousands of USD)") +
  ylab("\nModels")

#Density Plot comparing the Predicted Sale Price vs Density by the ML Models
ggplot(master) +
  aes(x = SalePrice/10000, color = Model, fill = Model) +
  geom_density() +
  scale_color_hue(direction = 1) +
  theme_minimal() +
  facet_wrap(vars(Model)) +
  theme(plot.title = element_text(size = 12, vjust = 3.2, hjust = 0.5)) +
  labs(title = "Predicted Sale Price vs Density by Machine Learning Models") +
  xlab("\nPredicted Sale Price (Ten Thousands of USD)") 

