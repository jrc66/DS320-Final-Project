library(data.table)
library(caret)
library(Metrics)
library(xgboost)
rm(list = ls())

set.seed(123)
data1 <-fread('./project/volume/data/raw/Stat_380_train.csv')
kaggle_data <- fread('./project/volume/data/raw/kaggle_data.csv')

#Data Integration
#Create a datatable using only 17 columns from kaggle_data
data2 <- data.table(Id = kaggle_data$Id, LotFrontage = kaggle_data$LotFrontage, LotArea = kaggle_data$LotArea, BldgType = kaggle_data$BldgType, OverallQual = kaggle_data$OverallQual, OverallCond = kaggle_data$OverallCond, FullBath = kaggle_data$FullBath, HalfBath = kaggle_data$HalfBath, TotRmsAbvGrd = kaggle_data$TotRmsAbvGrd, YearBuilt = kaggle_data$YearBuilt, TotalBsmtSF = kaggle_data$TotalBsmtSF, BedroomAbvGr = kaggle_data$BedroomAbvGr, Heating = kaggle_data$Heating, CentralAir = kaggle_data$CentralAir, GrLivArea = kaggle_data$GrLivArea, PoolArea = kaggle_data$PoolArea, YrSold = kaggle_data$YrSold, SalePrice = kaggle_data$SalePrice)
data <- rbind(data1, data2)
data$SalePrice <- as.numeric(data$SalePrice)
fwrite(data, "./project/volume/data/processed/data.csv")
data <- fread('./project/volume/data/processed/data.csv')

#split data into training (70%) and testing (30%) sets
split1<- sample(c(rep(0, 0.7 * nrow(data1)), rep(1, 0.3 * nrow(data1))))
train <- data1[split1 == 0, ]    
test <- data1[split1== 1, ]   

y.train <- train$SalePrice
y.test <- test$SalePrice
test$SalePrice <- 0

dummies <- dummyVars(SalePrice ~ ., data = train)

x.train <- predict(dummies, newdata = train)

x.test <- predict(dummies, newdata = test)

train$SalePrice <- y.train

dtrain <- xgb.DMatrix(x.train,
                      label = y.train,
                      missing = NA)
dtest <- xgb.DMatrix(x.test,
                     missing = NA)

hyper_parm_tune <- NULL

myparam <- list(  objective           = "reg:squarederror",
                  gamma               = 0.02,
                  booster             = "gbtree",
                  eval_metric         = "rmse",
                  eta                 = 0.1,
                  max_depth           = 5,
                  min_child_weight    = 1,
                  subsample           = 1.0,   
                  colsample_bytree    = 1.0,
                  tree_method         = 'hist'
)
XGBfit <- xgb.cv( params = myparam,
                  nfold = 5,
                  nrounds = 100000,
                  missing = NA,
                  data = dtrain,
                  print_every_n = 1,
                  early_stopping_rounds = 25) 

best_tree_n <- unclass(XGBfit)$best_iteration
new_row <- data.table(t(myparam))
new_row$best_tree_n <- best_tree_n
test_error <- unclass(XGBfit)$evaluation_log[best_tree_n,]$test_rmse_mean
new_row$test_error <- test_error
hyper_parm_tune <- rbind(new_row, hyper_parm_tune)

watchlist <- list( train = dtrain)


XGBfit <- xgb.train( params = myparam,
                     nrounds = best_tree_n,
                     missing = NA,
                     data = dtrain,
                     watchlist = watchlist,
                     print_every_n = 1)


pred <- predict(XGBfit, newdata = dtest)

saveRDS(dummies,"./project/volume/models/SalePriceSL.dummies")
saveRDS(pred,"./project/volume/models/XGBfit.model")

test$Pred_SalePrice <- predict(XGBfit, newdata = dtest)
submit <- test[,.(Pred_SalePrice)]
submit[is.na(submit$Pred_SalePrice)] <- mean(train$SalePrice)

fwrite(test[,.(Id, SalePrice = submit$Pred_SalePrice)], "./project/volume/data/processed/submit_SL.csv")

#create actual and predicted for evaluation metrics
actual <- y.test
predictedSL <- submit$Pred_SalePrice

head(actual)
head(predictedSL)

#F1-Score
f1(actual, predictedSL)

#Root Mean Squared Error
rmse(actual, predictedSL)

#Mean Absolute Error
mae(actual, predictedSL)
