library(data.table)
library(caret)
library(Metrics)
rm(list = ls())

set.seed(123)
data1 <- fread('./project/volume/data/raw/Stat_380_train.csv')
kaggle_data <- fread('./project/volume/data/raw/kaggle_data.csv')

#Data Integration
#Create a datatable using only 17 columns from kaggle_data
data2 <- data.table(Id = kaggle_data$Id, LotFrontage = kaggle_data$LotFrontage, LotArea = kaggle_data$LotArea, BldgType = kaggle_data$BldgType, OverallQual = kaggle_data$OverallQual, OverallCond = kaggle_data$OverallCond, FullBath = kaggle_data$FullBath, HalfBath = kaggle_data$HalfBath, TotRmsAbvGrd = kaggle_data$TotRmsAbvGrd, YearBuilt = kaggle_data$YearBuilt, TotalBsmtSF = kaggle_data$TotalBsmtSF, BedroomAbvGr = kaggle_data$BedroomAbvGr, Heating = kaggle_data$Heating, CentralAir = kaggle_data$CentralAir, GrLivArea = kaggle_data$GrLivArea, PoolArea = kaggle_data$PoolArea, YrSold = kaggle_data$YrSold, SalePrice = kaggle_data$SalePrice)
data <- rbind(data1, data2)
data$SalePrice <- as.numeric(data$SalePrice)
fwrite(data, "./project/volume/data/processed/data.csv")
data <- fread('./project/volume/data/processed/data.csv')

#split data into training (70%) and testing (30%) sets
split1<- sample(c(rep(0, 0.7 * nrow(data1)), rep(1, 0.3 * nrow(data1))))
train <- data1[split1 == 0,]
test <- data1[split1== 1,]

#save actual test SalePrice
train_y <- train$SalePrice
test_y <- test$SalePrice
test$SalePrice <- 0

#dummy variables will split the variable into multiple variables containing boolean values
dummies <- dummyVars(SalePrice ~ ., data = train)

train <- predict(dummies, newdata = train)
train <- data.table(train)

test <- predict(dummies, newdata = test)
test <- data.table(test)

train$SalePrice <- train_y

#creating the linear model
fit <- lm(SalePrice ~ ., data = train)
summary(fit)

#creating the gaussian logistic model
glm_fit <- glm(SalePrice ~ ., family = gaussian, data = train)
summary(glm_fit)

#creating the poisson logistic model
plm_fit <- glm(SalePrice ~ ., family = poisson, data = train)
summary(plm_fit)

saveRDS(dummies,"./project/volume/models/SalePriceRegression.dummies")
saveRDS(fit,"./project/volume/models/fit_lm.model")
saveRDS(glm_fit,"./project/volume/models/glm_fit.model")
saveRDS(plm_fit,"./project/volume/models/plm_fit.model")


#predicting the sale price using the linear model
test$Pred_SalePrice <- predict(fit, newdata = test)
submit_lm <- test[,.(Pred_SalePrice)]
submit_lm[is.na(submit_lm$Pred_SalePrice)] <- mean(train$SalePrice)
fwrite(test[,.(Id, SalePrice = submit_lm$Pred_SalePrice)], "./project/volume/data/processed/submit_lm.csv")

#predicting the sale price using the gaussian logistic model
test$Pred_result <- predict(glm_fit, newdata = test, type = "response")
submit_glm <- test[,.(Pred_result)]
submit_glm[is.na(submit_glm$Pred_result)] <- mean(train$SalePrice)
fwrite(test[,.(Id, result = submit_glm$Pred_result)], "./project/volume/data/processed/submit_glm.csv")

#predicting the sale price using the poisson logistic model
test$Pred_result2 <- predict(plm_fit, newdata = test, type = "response")
submit_plm <- test[,.(Pred_result2)]
submit_plm[is.na(submit_plm$Pred_result2)] <- mean(train$SalePrice)
fwrite(test[,.(Id, result = submit_plm$Pred_result2)], "./project/volume/data/processed/submit_plm.csv")

#create actual and predicted for evaluation metrics
actual <- test_y
predictedLM <- submit_lm$Pred_SalePrice
predictedGLM <- submit_glm$Pred_result
predictedPLM <- submit_plm$Pred_result2

head(actual)
head(predictedLM)

#F1-Score
f1(actual, predictedLM)
f1(actual, predictedGLM)
f1(actual, predictedPLM)

#Root Mean Squared Error
rmse(actual, predictedLM)
rmse(actual, predictedGLM)
rmse(actual, predictedPLM)

#Mean Absolute Error
mae(actual, predictedLM)
mae(actual, predictedGLM)
mae(actual, predictedPLM)

#R-squared
1 - (glm_fit$deviance / glm_fit$null.deviance)
1 - (plm_fit$deviance / plm_fit$null.deviance)

